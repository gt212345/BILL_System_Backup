package com.usc.bill.api;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.usc.bill.model.Type;
import com.usc.bill.model.ClassStatus;
import com.usc.bill.model.College;
import com.usc.bill.model.InternationalStatus;
import com.usc.bill.model.Role;
import com.usc.bill.model.Scholarship;
import com.usc.bill.model.Semester;
import com.usc.bill.model.StudentCourse;
import com.usc.bill.model.StudentCourse.CourseId;
import com.usc.bill.model.StudentProfile;
import com.usc.bill.model.StudyAbroad;
import com.usc.bill.model.TransactionHistory;
import com.usc.bill.model.User;
import com.usc.bill.utility.ChargeCalculator;

/**
 * ChargeCalculatorTest.java Purpose: ChargeCalculatorTest is a class designed
 * to exercise the methods of the ChargeCalculator class using JUnit.
 * 
 * A variety of configurations of a Student Profile will be createed and passed
 * to the Charge Calculator to verify tuition rates, fees, & final charges are
 * correct.
 * 
 * @author Wu, Alamri, Stroud
 * @version 1.0 11/29/2017
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class ChargeCalculatorTest {

	static StudentProfile studentProfile1;

	// Use @Before to establish a studentProfile for use across this class. We'll
	// call her "Becky", with id of 1234.
	@Before
	public void setUp() throws Exception {
		studentProfile1 = new StudentProfile();
		User user = new User();
		user.setCollege(College.ENGINEERING_AND_COMPUTING);
		user.setFirstName("Becky");
		user.setLastName("Beckworth");
		user.setId("1234");
		user.setRole(Role.STUDENT);
		studentProfile1.setUser(user);
		studentProfile1.setId(1234);
		studentProfile1.setPhone("888-888-8888");
		studentProfile1.setEmailAddress("becky@email.sc.edu");
		studentProfile1.setAddressStreet("888 Cabbot Cove");
		studentProfile1.setAddressCity("Chapin");
		studentProfile1.setAddressState("SC");
		studentProfile1.setAddressPostalCode("29036");
		studentProfile1.setActiveDuty(false);
		studentProfile1.setGradAssistant(false);
		studentProfile1.setInternational(true);
		studentProfile1.setInternationalStatus(InternationalStatus.SHORT_TERM);
		studentProfile1.setResident(true);
		studentProfile1.setClassStatus(ClassStatus.JUNIOR);
		studentProfile1.setVeteran(false);
		studentProfile1.setFreeTuition(true);
		studentProfile1.setScholarship(Scholarship.NONE);
		studentProfile1.setSemesterBegin(Semester.SUMMER);
		studentProfile1.setYearBegin(2016);
		studentProfile1.setStudyAbroad(StudyAbroad.NONE);
		studentProfile1.setNationalStudentExchange(true);
		studentProfile1.setOutsideInsurance(false);
		Set<StudentCourse> courses = new java.util.HashSet<>();
		StudentCourse course = new StudentCourse();
		CourseId id = new CourseId();
		id.setId("STAT 215");
		id.setOnline(false);
		course.setCourseId(id);
		course.setName("Statistics");
		course.setNumCredits(4);
		courses.add(course);
		studentProfile1.setStudentCourses(courses);
	}

	@Test
	public void testCalculateBalance() throws Exception {
		// Create a dummy List of transaction histories.
		List<TransactionHistory> histories = new ArrayList<>();

		// Create a Transaction HIstory for a charge of $100, remember charges are
		// negative when applied to a bill.
		TransactionHistory history = new TransactionHistory();
		history.setAmount(new BigDecimal(100));
		history.setDate(new Date());
		history.setId(123);
		history.setNote("This is a note");
		history.setType(Type.CHARGE);
		history.setUser(new User());
		histories.add(history);

		// The calculated balance based on this one transaction history should be -100.
		assertEquals(new BigDecimal(-100), ChargeCalculator.calculateBalance(histories));

		// Now add a payment of $50 to the transaction history, remember payments are
		// positive when applied to a bill.
		TransactionHistory history2 = new TransactionHistory();
		history2.setAmount(new BigDecimal(50));
		history2.setDate(new Date());
		history2.setId(123);
		history2.setNote("This is a note");
		history2.setType(Type.PAYMENT);
		history2.setUser(new User());
		histories.add(history2);

		// Now the calculated balance should be (-100 + 50) = -50.
		assertEquals(new BigDecimal(-50), ChargeCalculator.calculateBalance(histories));
	}

	@Test
	public void testCalculateTuitionWhenFree() {
		// Our dummy studentProfile has freeTuition = true, so if we calulcate Tuition
		// it should return 0.
		assertEquals(new BigDecimal(0), ChargeCalculator.calculateTuition(studentProfile1).get("FREE TUITION"));
	}

	@Test
	public void testCalculateFee() {
		// Technology Fee is for our undergraduate student profile is $17 per credit
		// hour.
		// Student profile has 4 credit hours so assert this fee is 4x17=68.
		assertEquals("68.0", (ChargeCalculator.calculateFee(studentProfile1).get("TECHNOLOGY FEE").toString()));
	}

	@Test
	public void testGraduateStudentResidentTotalCreditGreaterThanSEVENTEEN() {
		// Add another course to this student profile to forct it over 17 credit hours.
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithHugeCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithHugeCreditHour.setCourseId(courseId);
		courseWithHugeCreditHour.setName("name");
		courseWithHugeCreditHour.setNumCredits(17);
		courses.add(courseWithHugeCreditHour);

		// Now change the student profile to be a Graduate Student (i.e. PHD or Masters)
		// and set other attributes
		// necessary to be eligible for the special Gradaute Resident 17+ & Up fee.
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(true);
		studentProfile1.setInternational(false);
		studentProfile1.setClassStatus(ClassStatus.PHD);

		// Assert this fee has been applied and it's cost was $80.
		assertEquals(BigDecimal.valueOf(80.0),
				ChargeCalculator.calculateFee(studentProfile1).get("GRADUATE - RESIDENT - 17 HOURS AND ABOVE FEE"));
	}

	@Test
	public void testGraduateStudentNoneResidentTotalCreditGreaterThanSEVENTEEN() {
		// Run same test as above, meaning add a huge credit hour course to up hours
		// over 17.
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithHugeCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithHugeCreditHour.setCourseId(courseId);
		courseWithHugeCreditHour.setName("name");
		courseWithHugeCreditHour.setNumCredits(17);
		courses.add(courseWithHugeCreditHour);

		// this time though set the student profile to be a NON resident. This will
		// charge the Grad NON Resident 17+ Fee
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(false);
		studentProfile1.setInternational(false);
		studentProfile1.setClassStatus(ClassStatus.PHD);

		// Assert the fee was applied and the cost was $170.
		assertEquals(BigDecimal.valueOf(170.0),
				ChargeCalculator.calculateFee(studentProfile1).get("GRADUATE - NONRESIDENT - 17 HOURS AND ABOVE FEE"));
	}

	@Test
	public void testUnderGradStudentNoneResidentTotalCreditGreaterThanSEVENTEEN() {
		// Modify dummy student to have huge hours, but be non resident & undergrad.
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithHugeCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithHugeCreditHour.setCourseId(courseId);
		courseWithHugeCreditHour.setName("name");
		courseWithHugeCreditHour.setNumCredits(17);
		courses.add(courseWithHugeCreditHour);
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(false);
		studentProfile1.setInternational(false);
		studentProfile1.setClassStatus(ClassStatus.JUNIOR);

		// Verify the Undergrad Non Resident 17+ fee of $208 was charged.
		assertEquals(BigDecimal.valueOf(208.0), ChargeCalculator.calculateFee(studentProfile1)
				.get("UNDERGRADUATE - NONRESIDENT - 17 HOURS AND ABOVE FEE"));
	}

	@Test
	public void testGradStudentNoneStudyAbroadNineToEleven() {
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithHugeCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithHugeCreditHour.setCourseId(courseId);
		courseWithHugeCreditHour.setName("name");
		courseWithHugeCreditHour.setNumCredits(6);
		courses.add(courseWithHugeCreditHour);
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(false);
		studentProfile1.setInternational(false);
		studentProfile1.setStudyAbroad(StudyAbroad.NONE);
		studentProfile1.setClassStatus(ClassStatus.PHD);
		assertEquals(BigDecimal.valueOf(178.0), ChargeCalculator.calculateFee(studentProfile1)
				.get("GRADUATE STUDENTS - (9 TO 11 HOURS) - REQUIRED STUDENT HEALTH CENTER FEE - PER SEMESTER"));
	}

	@Test
	public void testGradStudentNoneStudyAbroadSixToEight() {
		// Set student record to have 7 hours (original 4 + 3 more), and make Grad
		// student.
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithHugeCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithHugeCreditHour.setCourseId(courseId);
		courseWithHugeCreditHour.setName("name");
		courseWithHugeCreditHour.setNumCredits(3);
		courses.add(courseWithHugeCreditHour);
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(false);
		studentProfile1.setInternational(false);
		studentProfile1.setStudyAbroad(StudyAbroad.NONE);
		studentProfile1.setClassStatus(ClassStatus.PHD);

		// Verify the rad 608 Hour Health Center fee of $119 was applied, study abroad
		// must be false.
		assertEquals(BigDecimal.valueOf(119.0), ChargeCalculator.calculateFee(studentProfile1)
				.get(" GRADUATE STUDENTS - (6 TO 8 HOURS) - REQUIRED STUDENT HEALTH CENTER FEE - PER SEMESTER"));
	}

	@Test
	public void testGradStudentIntSponsoredCreditGreaterThanTwelve() {
		// More special fee tests. Make this student a Sponosored inteernational student
		// with more than 12 hours.
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithHugeCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithHugeCreditHour.setCourseId(courseId);
		courseWithHugeCreditHour.setName("name");
		courseWithHugeCreditHour.setNumCredits(9);
		courses.add(courseWithHugeCreditHour);
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(false);
		studentProfile1.setInternational(true);
		studentProfile1.setInternationalStatus(InternationalStatus.SPONSORED);

		// Verify the Sponsored Int Student fee of $250 was charged.
		assertEquals(BigDecimal.valueOf(250.0),
				ChargeCalculator.calculateFee(studentProfile1).get("SPONSORED INTERNATIONAL STUDENT FEE"));
	}

	@Test
	public void testGradStudentResidentTuition() {
		// Set student to be a Grad & resident.
		studentProfile1.setClassStatus(ClassStatus.PHD);
		studentProfile1.setInternational(false);
		studentProfile1.setInternationalStatus(InternationalStatus.NONE);
		studentProfile1.setResident(true);
		studentProfile1.setGradAssistant(false);

		// Verfiy the Grad Resident Tuition fee was charge and was $2132 since it is
		// $533 per hour & he has 4 hours.
		assertEquals(BigDecimal.valueOf(2132.0),
				ChargeCalculator.calculateTuition(studentProfile1).get("GRADUATE - RESIDENT - TUITION"));
	}

	@Test
	public void testGradStudentNotResidentGradAssistantTuition() {
		// configure student to be a Grad & non-resident, plus a Graduate Assistant.
		studentProfile1.setClassStatus(ClassStatus.PHD);
		studentProfile1.setResident(false);
		studentProfile1.setGradAssistant(true);

		// The tuition for a Non Reeident Grad Student who is also a Grad Assistant,
		// should be calculated
		// as the Non-Resident Grad rate, less the Resident Grad rate due to the
		// Assistant postion.
		// Figure 4 hours x (1142-533) and assert.
		assertEquals(BigDecimal.valueOf(2436.0),
				ChargeCalculator.calculateTuition(studentProfile1).get("NON-RESIDENT GRADUATE ASSISTANT TUITION"));
	}

	@Test
	public void testGradStudentNotResidentStudyAbroadTuition() {
		// Make student a Graduate & Non Resident, this time not a graduate assistant
		// but they are studying abroad.
		studentProfile1.setClassStatus(ClassStatus.PHD);
		studentProfile1.setResident(false);
		studentProfile1.setGradAssistant(false);
		studentProfile1.setStudyAbroad(StudyAbroad.REGULAR);

		// Tuition is a again the difference between Grad Non Resident & Resident Rates,
		// times credit hours. $2,346.
		assertEquals(BigDecimal.valueOf(2436.0),
				ChargeCalculator.calculateTuition(studentProfile1).get("GRADUATE - STUDY ABROAD - TUITION"));
	}

	@Test
	public void testGradStudentNotResidentTuition() {
		// Make student a Graduate Student, non Resident, and no special category
		// otherwise.
		studentProfile1.setClassStatus(ClassStatus.PHD);
		studentProfile1.setResident(false);
		studentProfile1.setGradAssistant(false);
		studentProfile1.setStudyAbroad(StudyAbroad.NONE);

		// Assert straight non resident graduate rate of $1142 x 4 credit hours = $4,568
		assertEquals(BigDecimal.valueOf(4568.0),
				ChargeCalculator.calculateTuition(studentProfile1).get("GRADUATE - NONRESIDENT - TUITION"));
	}

	@Test
	public void testGetOnlineCreditHour() {
		// Because all prevous tests have only used non-online courses, add one that is
		// online=true.
		Set<StudentCourse> courses = new java.util.HashSet<>();
		StudentCourse onlineCourse = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("onlineCourseId");
		courseId.setOnline(true);
		onlineCourse.setCourseId(courseId);
		onlineCourse.setName("name");
		onlineCourse.setNumCredits(3);
		courses.add(onlineCourse);

		// Assert a simple case for now that the chargeCalculator at least recognized
		// this new course to be online, and it is 3 credit hours.
		assertEquals(3, ChargeCalculator.getOnlineCreditHours(courses));
	}

	@Test
	public void testGetFinalCharges() {
		// Configure our dummy student to be a Graduate Student, non Res, and nothing
		// else special with regard to study abroad or assistant.
		studentProfile1.setClassStatus(ClassStatus.PHD);
		studentProfile1.setResident(false);
		studentProfile1.setGradAssistant(false);
		studentProfile1.setStudyAbroad(StudyAbroad.NONE);

		// the sum of all charges for this student should only be the tuition calculated
		// in testGradStudentNonRewsident of $1142x4=$4568
		// plus the technology fee we calculated in testCalculateFee, which was $17x4
		// credit hours = $68.
		// Total final charges are then $4,636.
		assertEquals(BigDecimal.valueOf(4636.0), ChargeCalculator.calculateFinalCharges(studentProfile1));
	}

	@Test
	public void testEmptyStudentProfileCalculateTuition() {
		try {
			ChargeCalculator.calculateTuition(new StudentProfile());
		} catch (NullPointerException e) {
			fail("The input profile was null");
		}
	}

	@Test
	public void testMinusCreditHourCalculateTuition() {
		// More special fee tests. Make this student with minus credit hours
		Set<StudentCourse> courses = studentProfile1.getStudentCourses();
		StudentCourse courseWithMinusCreditHour = new StudentCourse();
		CourseId courseId = new CourseId();
		courseId.setId("id");
		courseId.setOnline(false);
		courseWithMinusCreditHour.setCourseId(courseId);
		courseWithMinusCreditHour.setName("name");
		courseWithMinusCreditHour.setNumCredits(-9);
		courses.add(courseWithMinusCreditHour);
		studentProfile1.setStudentCourses(courses);
		studentProfile1.setResident(false);
		studentProfile1.setInternational(true);
		studentProfile1.setInternationalStatus(InternationalStatus.SPONSORED);

		// Verify the Technology fee, should be null but returned minus value
		assertNull(ChargeCalculator.calculateFee(studentProfile1).get("TECHNOLOGY FEE"));
	}

}
